<div class="jumbotron" style="margin-top:50px">
      <div class="row">
      <div class="col-md-5">
     <img src="../../img/buku31.jpg" style="width:400px;height:400px;">   
    </div>
      <div class="col-md-6" style="margin-top: 50px;">
        <h2><b>Selamat datang di Halaman ADMIN</b></h2>
        <p>Disini anda bisa memanegeman dari data <b>Kategori</b>, <b>Buku</b> dan data <b>Customer</b></p>
      </div>
    </div>
    </div>